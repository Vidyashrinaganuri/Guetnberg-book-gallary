import React, { useState, useEffect } from "react";
import { makeStyles } from "@material-ui/core/styles";
import Card from "@material-ui/core/Card";
import { Container, Grid } from "@material-ui/core";
import CardActionArea from "@material-ui/core/CardActionArea";
import CardMedia from "@material-ui/core/CardMedia";
import Typography from "@material-ui/core/Typography";
import Icon from "@material-ui/icons/Search";
import Close from "@material-ui/icons/Close";
import ArrowBackIcon from "@material-ui/icons/ArrowBack";
import { useHistory } from "react-router-dom";
import { FlashOnRounded } from "@material-ui/icons";

const useStyles = makeStyles((theme) => ({
  mainDiv: {
    paddingTop: 50,
  },
  root: {
    width: "114px",
    borderRadius: "8px",
    backgroundColor: "transparent",
    boxShadow: "0 2px 5px 0 rgba(211, 209, 238, 0.5)",
    marginRight: 30,
  },
  header: {
    fontFamily: " Montserrat",
    fontSize: "12px",
    textTransform: "uppercase",
    paddingTop: 5,
    fontWeight: "600",
    width: "114px",
  },
  author: {
    fontFamily: " Montserrat",
    fontSize: "12px",
    textTransform: "capitalize",
    fontWeight: "600",
    color: "gray",
    width: "114px",
    marginBottom: 30,
  },
  imagetag: {
    width: "114px",
    height: "162px",
    boxShadow: "0 2px 5px 0 rgba(211, 209, 238, 0.5)",
  },
  searchBar: {
    width: 850,
    [theme.breakpoints.down("xs")]: {
      width: 300,
    },
    marginBottom: 20,
    paddingLeft: 60,
    backgroundColor: "#F0F0F6",
    borderColor: "#F0F0F6",
    fontFamily: "Montserrat",
    "&:hover": {
      borderColor: "#5E56E7",
      boderWidth: 1,
    },
    cursor: "pointer",
    borderRadius: "4px",
    PaddingLeft: "10px",
    height: "40px",
  },
  sunDiv: {
    backgroundColor: "#fff",
    display: "flex",
    flexDirection: "row",
  },
  h5: {
    color: "#5e56e7",
    fontWeight: "600",
    fontFamily: "Montserrat",
    marginBottom: 20,
  },
  headerDiv: {
    position: "absolute",
    marginLeft: 810,
    [theme.breakpoints.down("xs")]: {
      marginLeft: 270,
    },
    marginTop: 10,
    height: 100,
  },
  iconSty: {
    position: "absolute",
    marginLeft: 30,
    marginTop: 9,
    color: "#A0A0A0",
  },
  divTag: {
    backgroundColor: "#F8F7FF",
    paddingTop: 50,
    height: window.innerHeight,
  },
  secondMainDiv: {
    display: "flex",
    flexWrap: "wrap",
    backgroundColor: "#F8F7FF",
  },
  generalCard: {
    fontSize: "20px",
    fontWeight: "600",
  },
}));

export default function ImgMediaCard() {
  const classes = useStyles();
  const [data, setData] = useState([]);
  const [search, setSearch] = useState("");
  const [focus, setFocus] = useState(false);
  const history = useHistory();

  useEffect(() => {
    fetch("http://skunkworks.ignitesol.com:8000/books/")
      .then((response) => response.json())
      .then((data) => setData(data.results))
      .catch((err) => {
        console.log(err);
      });
  });
  function handleChange(e) {
    setSearch(e.target.value.toLowerCase());
  }
  function onPassToHome() {
    history.push("/");
  }
  function resetFun() {
    setSearch("");
  }

  return (
    <div className={classes.mainDiv}>
      <div className={classes.sunDiv}>
        <Container maxWidth="md">
          <div>
            <h3 className={classes.h5}>
              <ArrowBackIcon fontSize="large" onClick={() => onPassToHome()} />
              Fiction
            </h3>
          </div>
          <Grid item xs={12} md={9} sm={6}>
            <div>
              <div className={classes.headerDiv}>
                <Close
                  style={{
                    position: "absolute",
                    color: search ? "#A0A0A0" : "#F0F0F6",
                  }}
                  onClick={() => resetFun()}
                >
                  Close
                </Close>
              </div>
              <div>
                <form>
                  <Icon className={classes.iconSty}>search</Icon>

                  <input
                    type="text"
                    label="Name"
                    xs={12}
                    value={search}
                    className={classes.searchBar}
                    onChange={handleChange}
                  />
                </form>
              </div>
            </div>
          </Grid>
        </Container>
      </div>

      <div className={classes.divTag}>
        <Container maxWidth="md">
          <Grid Container>
            {search === "" ? (
              <Grid
                item
                xs={12}
                style={{
                  display: "flex",
                  flexWrap: "wrap",
                }}
              >
                {data.map((row) => {
                  return (
                    <div>
                      <Card className={classes.root}>
                        <CardActionArea>
                          <CardMedia
                            component="img"
                            alt="Contemplative Reptile"
                            className={classes.imagetag}
                            image={
                              row.formats["image/jpeg"]
                                ? row.formats["image/jpeg"]
                                : "http://www.gutenberg.org/cache/epub/76/pg76.cover.medium.jpg"
                            }
                            //   image="https://d1csarkz8obe9u.cloudfront.net/posterpreviews/science-fiction-book-cover-design-template-b3ebf6385a80a0f8a08d5e813d2bdf44_screen.jpg?ts=1606740314"
                            title="Contemplative Reptile"
                          />
                        </CardActionArea>
                      </Card>
                      <Typography
                        gutterBottom
                        variant="h5"
                        component="h2"
                        className={classes.header}
                      >
                        {row.title.split(":")[0]}
                      </Typography>
                      <Typography
                        gutterBottom
                        variant="h5"
                        component="h2"
                        className={classes.author}
                      >
                        {row.authors.map((a) => a.name)}
                      </Typography>
                    </div>
                  );
                })}
              </Grid>
            ) : (
              <Grid item xs={12} className={classes.secondMainDiv}>
                {data.map((row) => (
                  <div>
                    {row.title.toLowerCase().includes(search) ||
                    row.authors
                      .map((a) => a.name.toLowerCase())
                      .includes(search) ? (
                      <div>
                        <Card className={classes.root}>
                          <CardActionArea>
                            <CardMedia
                              component="img"
                              alt="Contemplative Reptile"
                              className={classes.imagetag}
                              image={
                                row.formats["image/jpeg"]
                                  ? row.formats["image/jpeg"]
                                  : "http://www.gutenberg.org/cache/epub/76/pg76.cover.medium.jpg"
                              }
                              title="Contemplative Reptile"
                            />
                          </CardActionArea>
                        </Card>
                        <Typography
                          gutterBottom
                          variant="h5"
                          component="h2"
                          className={classes.header}
                        >
                          {row.title.split(":")[0]}
                        </Typography>
                        <Typography
                          gutterBottom
                          variant="h5"
                          component="h2"
                          className={classes.author}
                        >
                          {row.authors.map((a) => a.name)}
                        </Typography>
                      </div>
                    ) : (
                      <div></div>
                    )}
                  </div>
                ))}
              </Grid>
            )}
          </Grid>
        </Container>
      </div>
    </div>
  );
}
