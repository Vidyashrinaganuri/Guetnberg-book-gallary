import React from "react";
import { Container, Card, Grid, Typography } from "@material-ui/core";
import {
  ArrowForward,
  LocalBarTwoTone,
  MoodTwoTone,
  ImportContactsTwoTone,
  PanToolTwoTone,
  EmojiPeopleTwoTone,
  AllOutTwoTone,
} from "@material-ui/icons";
import { makeStyles } from "@material-ui/core";
import { useHistory } from "react-router-dom";

const useStyles = makeStyles((theme) => ({
  mainDiv: {
    paddingTop: 50,
    backgroundColor: "#F8F7FF",
    height: window.innerHeight,
  },
  header: {
    color: "#5e56e7",
    fontSize: "48px",
    fontWeight: "600",
    fontFamily: "Montserrat",
  },
  categorycard: {
    paddingLeft: " 10px",
    paddingright: "10px",
    borderRadius: "4px",
    boxShadow: " 0 2px 5px 0 rgba(211, 209, 238, 0.5)",
    height: " 50px",
    width: " 420px",
    marginTop: "30px",
    alignItems: "center",
    fontWeight: "bold",
    display: "flex",
    fontFamily: "Montserrat",
  },
  cardTag: {
    color: "#5e56e7",
    marginRight: 10,
    fontSize: 32,
  },
  arrowForward: {
    color: "#5e56e7",
    marginLeft: "auto",
    marginRight: 10,
    fontSize: 32,
  },
  gridStyle: {
    display: "flex",
    flexWrap: "wrap",
    backgroundColor: "#F8F7FF",
    justifyContent: "space-between",
  },
  content: {
    fontSize: "20px",
    fontWeight: "600",
    color: "#000",
    fontFamily: "Montserrat",
  },
  generalCard: {
    fontSize: "20px",
    fontWeight: "600",
  },
}));

export default function StyledComponents() {
  const classes = useStyles();
  const history = useHistory();

  // const names = [
  //   { id: 1, name: "FICTION", price: "FilterDrama" },
  //   { id: 2, name: "PHILOSOPHY", price: "FilterDrama" },
  //   { id: 3, name: "DRAMA", price: "FilterDrama" },
  //   { id: 1, name: "HISTORY", price: "FilterDrama" },
  //   { id: 2, name: "HUMOUR", price: "FilterDrama" },
  //   { id: 3, name: "ADVENTURE", price: "FilterDrama" },
  //   { id: 3, name: "POLITICS", price: "FilterDrama" },
  // ];

  function onPassToBooks() {
    history.push("/booksgallery");
  }

  return (
    <div className={classes.mainDiv}>
      <Container maxWidth="md">
        <Grid Container>
          <Typography item xs={12} className={classes.header}>
            Guitenberg Project
            <Typography item xs={12} className={classes.content}>
              A social cataloging website that allows you to freely search its
              database of books, annotations, and reviews.
            </Typography>
          </Typography>

          <Grid
            item
            xs={12}
            md={12}
            sm={12}
            lg={12}
            className={classes.gridStyle}
          >
            <Card item className={classes.categorycard}>
              <LocalBarTwoTone className={classes.cardTag} />
              <Typography className={classes.generalCard}>FICTION</Typography>
              <ArrowForward
                className={classes.arrowForward}
                onClick={() => onPassToBooks()}
              />
            </Card>
            <Card item className={classes.categorycard}>
              <MoodTwoTone className={classes.cardTag} />
              <Typography className={classes.generalCard}>
                PHILOSOPHY
              </Typography>

              <ArrowForward className={classes.arrowForward} />
            </Card>
            <Card item className={classes.categorycard}>
              <AllOutTwoTone className={classes.cardTag} />
              <Typography className={classes.generalCard}>DRAMA</Typography>

              <ArrowForward className={classes.arrowForward} />
            </Card>
            <Card item className={classes.categorycard}>
              <ImportContactsTwoTone className={classes.cardTag} />
              <Typography className={classes.generalCard}>HISTORY</Typography>

              <ArrowForward className={classes.arrowForward} />
            </Card>
            <Card item className={classes.categorycard}>
              <MoodTwoTone className={classes.cardTag} />
              <Typography className={classes.generalCard}>HUMOUR</Typography>

              <ArrowForward className={classes.arrowForward} />
            </Card>
            <Card item className={classes.categorycard}>
              <EmojiPeopleTwoTone className={classes.cardTag} />
              <Typography className={classes.generalCard}>ADVENTURE</Typography>

              <ArrowForward className={classes.arrowForward} />
            </Card>
            <Card item className={classes.categorycard}>
              <PanToolTwoTone className={classes.cardTag} />
              <Typography className={classes.generalCard}>POLITICS</Typography>

              <ArrowForward
                className={classes.arrowForward}
                onClick={() => onPassToBooks()}
              />
            </Card>
          </Grid>
        </Grid>
      </Container>
    </div>
  );
}
