import React, { Component } from "react";
import Home1 from "./components/Home.js";
import Fiction from "./components/Fiction.js";
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link
} from "react-router-dom";

export default class App extends Component {
  render() {
    return (
      <Router>
      <div>
       
        <Switch>
          <Route path="/about">
            <Home1 />
          </Route>
          <Route path="/booksgallery">
            <Fiction />
          </Route>
          <Route path="/">
            <Home1 />
          </Route>
        </Switch>
      </div>
    </Router>
    );
  }
}
